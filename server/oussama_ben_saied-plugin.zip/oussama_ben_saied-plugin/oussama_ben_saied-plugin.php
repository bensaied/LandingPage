<?php
/**
 * Plugin Name: Oussama Ben Saied Plugin
 * Description: A custom plugin to handle form submissions.
 * Version: 1.0
 * Author: Oussama Ben Saied
 */


 if (!defined('ABSPATH')) {
    exit;
}

// Register Custom Post Type
function create_form_cpt() {
    $labels = array(
        'name' => _x('Forms', 'Post Type General Name', 'textdomain'),
        'singular_name' => _x('Form', 'Post Type Singular Name', 'textdomain'),
        'menu_name' => __('Forms', 'textdomain'),
        'name_admin_bar' => __('Form', 'textdomain'),
    );
    $args = array(
        'label' => __('Form', 'textdomain'),
        'labels' => $labels,
        'supports' => array('title', 'custom-fields'),
        'public' => false,
        'show_ui' => true,
        'show_in_menu' => true,
        'show_in_admin_bar' => true,
        'show_in_nav_menus' => false,
        'can_export' => true,
        'has_archive' => false,
        'exclude_from_search' => true,
        'publicly_queryable' => false,
        'capability_type' => 'post',
    );
    register_post_type('form', $args);
}
add_action('init', 'create_form_cpt', 0);

// Register REST API Endpoint
function register_form_endpoint() {
    register_rest_route('oussama_ben_saied/v1', '/contact-form', array(
        'methods' => 'POST',
        'callback' => 'handle_form_submission',
        'permission_callback' => '__return_true', 
    ));
}
add_action('rest_api_init', 'register_form_endpoint');

// Handle Form Submission
function handle_form_submission($request) {
    $name = sanitize_text_field($request->get_param('name'));
    $email = sanitize_email($request->get_param('email'));
    $message = sanitize_textarea_field($request->get_param('message'));

    if (empty($name) || empty($email) || empty($message)) {
        return new WP_Error('missing_field', 'Please provide all required fields.', array('status' => 400));
    }

    $args = array(
        'post_type' => 'form',
        'meta_query' => array(
            array(
                'key' => 'email',
                'value' => $email,
                'compare' => '=',
            ),
        ),
        'date_query' => array(
            array(
                'after' => '1 hour ago',
            ),
        ),
    );
    $query = new WP_Query($args);

    if ($query->have_posts()) {
        return new WP_Error('duplicate_email', 'Oops! You have already submitted a form with this email. Please come back after 1 hour.', array('status' => 400));
    }

    // Insert the form submission as a custom post type
    $post_id = wp_insert_post(array(
        'post_title' => $name,
        'post_type' => 'form',
        'post_status' => 'publish',
        'meta_input' => array(
            'email' => $email,
            'message' => $message,
        ),
    ));

    if (is_wp_error($post_id)) {
        return new WP_Error('submission_failed', 'Form submission failed.', array('status' => 500));
    }

    return array('success' => true, 'message' => 'Form submitted successfully.');
}
